﻿CREATE TABLE [dbo].[Person] 
/***************************************************************
* Name        : Phone Book
* Author      : Cody Hale
* Created     : 11/1/2019
* Course      : CIS 169 - C#
* Version     : 1.0
* OS          : Windows 10
* Copyright   : This is my own original work based on            *               specifications issued by our instructor
* Description : Creates a SQL database. A table of name/phone numbers
*               Input:  list and describe
*               Output: list and describe
* Academic Honesty: I attest that this is my original work.
* I have not used unauthorized source code, either modified or * * unmodified. I have not given other fellow student(s) access to * my program.         
***************************************************************/
(
    [PersonID] INT          IDENTITY (1, 1) NOT NULL,
    [Name]     VARCHAR (50) NOT NULL,
    [Phone]    VARCHAR (50) NOT NULL,
    PRIMARY KEY CLUSTERED ([PersonID] ASC)
);

