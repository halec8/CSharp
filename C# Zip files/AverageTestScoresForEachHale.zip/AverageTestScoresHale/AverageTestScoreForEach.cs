﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

/***************************************************************
* Name        : AverageTestScoresWhileHale
* Author      : Cody Hale
* Created     : 10/5/2019
* Course      : CIS 169 - C#
* Version     : 1.0
* OS          : Windows10
* Copyright   : This is my own original work based on            *               specifications issued by our instructor
* Description : Gathers input from the user for 4 test scores, calculates the average, then displays
*               Input:  the user inputs the test score values
*               Output: test score average
* Academic Honesty: I attest that this is my original work.
* I have not used unauthorized source code, either modified or * * unmodified. I have not given other fellow student(s) access to * my program.         
***************************************************************/


namespace AverageTestScoresHale
{ 
    /***************************************************************
* Name        : AverageTestScoreForEach
* Author      : Cody Hale
* Created     : 10/5/2019
***************************************************************/

    class AverageTestScoreForEach
    {

/**************************************************************
* Name:= Main
* Description: 
* Input: int/string/etc… , int/string/etc… field1, …
* Output: int/string/etc…, int/string/etc… field1, …
***************************************************************/


        static void Main(string[] args)

        {   // declare an array thats 4 elements

            const int SIZE = 4;
            double [] test = new double[SIZE];


            // beginning of the try catch to valid input.

            try
            {

                // for each loop that stores the inputed values into the array and displays 

                foreach (int number in test)
                {
                    Console.Write("Enter the first test score: ");

                    string test1 = Console.ReadLine();
                    double test1Score = Double.Parse(test1);

                    Console.Write("Enter the second test score: ");

                    string test2 = Console.ReadLine();
                    double test2Score = Double.Parse(test2);

                    Console.Write("Enter the third test score: ");

                    string test3 = Console.ReadLine();
                    double test3Score = double.Parse(test3);

                    Console.Write("Enter the fourth test score: ");

                    string test4 = Console.ReadLine();
                    double test4Score = double.Parse(test4);

                    // calculates the average for the test scores inputed

                    double testscoreAverage = (test1Score + test2Score + test3Score + test4Score) / 4;


                    // displays the test scores within the console/to the user.

                    Console.WriteLine("The average of your test scores is: " + testscoreAverage.ToString("n2"));
                }

            } // end of the try but beginning of the catch. This is what displays a message if invalid input is entered.

            catch (Exception ex)

            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
