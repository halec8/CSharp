﻿namespace ArithmeticOperations
{
    partial class arithmeticOperations
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.additionLabelbox = new System.Windows.Forms.Label();
            this.subtractionLabelbox = new System.Windows.Forms.Label();
            this.multiplicationLabelbox = new System.Windows.Forms.Label();
            this.divisionLabelbox = new System.Windows.Forms.Label();
            this.modulousLabelbox = new System.Windows.Forms.Label();
            this.increaseLabelbox = new System.Windows.Forms.Label();
            this.decreaseLabelbox = new System.Windows.Forms.Label();
            this.additionTextbox = new System.Windows.Forms.TextBox();
            this.subtractionTextbox = new System.Windows.Forms.TextBox();
            this.multiplicationTextbox = new System.Windows.Forms.TextBox();
            this.divisionTextbox = new System.Windows.Forms.TextBox();
            this.modulousTextbox = new System.Windows.Forms.TextBox();
            this.incrementIncreasetextbox = new System.Windows.Forms.TextBox();
            this.incrementDecreasetextbox = new System.Windows.Forms.TextBox();
            this.showAdditionbutton = new System.Windows.Forms.Button();
            this.showSubtractionbutton = new System.Windows.Forms.Button();
            this.showMultiplicationbutton = new System.Windows.Forms.Button();
            this.showDivisionbutton = new System.Windows.Forms.Button();
            this.showModulousbutton = new System.Windows.Forms.Button();
            this.showincreasebutton = new System.Windows.Forms.Button();
            this.showdecreasebutton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // additionLabelbox
            // 
            this.additionLabelbox.AutoSize = true;
            this.additionLabelbox.Location = new System.Drawing.Point(38, 53);
            this.additionLabelbox.Name = "additionLabelbox";
            this.additionLabelbox.Size = new System.Drawing.Size(90, 25);
            this.additionLabelbox.TabIndex = 0;
            this.additionLabelbox.Text = "Addition";
            this.additionLabelbox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // subtractionLabelbox
            // 
            this.subtractionLabelbox.AutoSize = true;
            this.subtractionLabelbox.Location = new System.Drawing.Point(38, 119);
            this.subtractionLabelbox.Name = "subtractionLabelbox";
            this.subtractionLabelbox.Size = new System.Drawing.Size(121, 25);
            this.subtractionLabelbox.TabIndex = 1;
            this.subtractionLabelbox.Text = "Subtraction";
            this.subtractionLabelbox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // multiplicationLabelbox
            // 
            this.multiplicationLabelbox.AutoSize = true;
            this.multiplicationLabelbox.Location = new System.Drawing.Point(38, 189);
            this.multiplicationLabelbox.Name = "multiplicationLabelbox";
            this.multiplicationLabelbox.Size = new System.Drawing.Size(138, 25);
            this.multiplicationLabelbox.TabIndex = 2;
            this.multiplicationLabelbox.Text = "Multiplication";
            this.multiplicationLabelbox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // divisionLabelbox
            // 
            this.divisionLabelbox.AutoSize = true;
            this.divisionLabelbox.Location = new System.Drawing.Point(38, 245);
            this.divisionLabelbox.Name = "divisionLabelbox";
            this.divisionLabelbox.Size = new System.Drawing.Size(88, 25);
            this.divisionLabelbox.TabIndex = 3;
            this.divisionLabelbox.Text = "Division";
            this.divisionLabelbox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // modulousLabelbox
            // 
            this.modulousLabelbox.AutoSize = true;
            this.modulousLabelbox.Location = new System.Drawing.Point(38, 316);
            this.modulousLabelbox.Name = "modulousLabelbox";
            this.modulousLabelbox.Size = new System.Drawing.Size(106, 25);
            this.modulousLabelbox.TabIndex = 4;
            this.modulousLabelbox.Text = "Modulous";
            this.modulousLabelbox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // increaseLabelbox
            // 
            this.increaseLabelbox.AutoSize = true;
            this.increaseLabelbox.Location = new System.Drawing.Point(38, 386);
            this.increaseLabelbox.Name = "increaseLabelbox";
            this.increaseLabelbox.Size = new System.Drawing.Size(194, 25);
            this.increaseLabelbox.TabIndex = 5;
            this.increaseLabelbox.Text = "Increment Increase";
            this.increaseLabelbox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // decreaseLabelbox
            // 
            this.decreaseLabelbox.AutoSize = true;
            this.decreaseLabelbox.Location = new System.Drawing.Point(38, 451);
            this.decreaseLabelbox.Name = "decreaseLabelbox";
            this.decreaseLabelbox.Size = new System.Drawing.Size(204, 25);
            this.decreaseLabelbox.TabIndex = 6;
            this.decreaseLabelbox.Text = "Increment Decrease";
            this.decreaseLabelbox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // additionTextbox
            // 
            this.additionTextbox.Location = new System.Drawing.Point(296, 47);
            this.additionTextbox.Name = "additionTextbox";
            this.additionTextbox.Size = new System.Drawing.Size(152, 31);
            this.additionTextbox.TabIndex = 7;
            this.additionTextbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // subtractionTextbox
            // 
            this.subtractionTextbox.Location = new System.Drawing.Point(296, 113);
            this.subtractionTextbox.Name = "subtractionTextbox";
            this.subtractionTextbox.Size = new System.Drawing.Size(152, 31);
            this.subtractionTextbox.TabIndex = 8;
            this.subtractionTextbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // multiplicationTextbox
            // 
            this.multiplicationTextbox.Location = new System.Drawing.Point(296, 183);
            this.multiplicationTextbox.Name = "multiplicationTextbox";
            this.multiplicationTextbox.Size = new System.Drawing.Size(152, 31);
            this.multiplicationTextbox.TabIndex = 9;
            this.multiplicationTextbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // divisionTextbox
            // 
            this.divisionTextbox.Location = new System.Drawing.Point(296, 248);
            this.divisionTextbox.Name = "divisionTextbox";
            this.divisionTextbox.Size = new System.Drawing.Size(152, 31);
            this.divisionTextbox.TabIndex = 10;
            this.divisionTextbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // modulousTextbox
            // 
            this.modulousTextbox.Location = new System.Drawing.Point(296, 310);
            this.modulousTextbox.Name = "modulousTextbox";
            this.modulousTextbox.Size = new System.Drawing.Size(152, 31);
            this.modulousTextbox.TabIndex = 11;
            this.modulousTextbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // incrementIncreasetextbox
            // 
            this.incrementIncreasetextbox.Location = new System.Drawing.Point(296, 380);
            this.incrementIncreasetextbox.Name = "incrementIncreasetextbox";
            this.incrementIncreasetextbox.Size = new System.Drawing.Size(152, 31);
            this.incrementIncreasetextbox.TabIndex = 12;
            this.incrementIncreasetextbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // incrementDecreasetextbox
            // 
            this.incrementDecreasetextbox.Location = new System.Drawing.Point(296, 445);
            this.incrementDecreasetextbox.Name = "incrementDecreasetextbox";
            this.incrementDecreasetextbox.Size = new System.Drawing.Size(152, 31);
            this.incrementDecreasetextbox.TabIndex = 13;
            this.incrementDecreasetextbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // showAdditionbutton
            // 
            this.showAdditionbutton.Location = new System.Drawing.Point(503, 30);
            this.showAdditionbutton.Name = "showAdditionbutton";
            this.showAdditionbutton.Size = new System.Drawing.Size(194, 48);
            this.showAdditionbutton.TabIndex = 14;
            this.showAdditionbutton.Text = "Show Operation";
            this.showAdditionbutton.UseVisualStyleBackColor = true;
            this.showAdditionbutton.Click += new System.EventHandler(this.ShowAdditionbutton_Click);
            // 
            // showSubtractionbutton
            // 
            this.showSubtractionbutton.Location = new System.Drawing.Point(503, 96);
            this.showSubtractionbutton.Name = "showSubtractionbutton";
            this.showSubtractionbutton.Size = new System.Drawing.Size(194, 48);
            this.showSubtractionbutton.TabIndex = 15;
            this.showSubtractionbutton.Text = "Show Operation";
            this.showSubtractionbutton.UseVisualStyleBackColor = true;
            this.showSubtractionbutton.Click += new System.EventHandler(this.ShowSubtractionbutton_Click);
            // 
            // showMultiplicationbutton
            // 
            this.showMultiplicationbutton.Location = new System.Drawing.Point(503, 169);
            this.showMultiplicationbutton.Name = "showMultiplicationbutton";
            this.showMultiplicationbutton.Size = new System.Drawing.Size(194, 45);
            this.showMultiplicationbutton.TabIndex = 16;
            this.showMultiplicationbutton.Text = "Show Operation";
            this.showMultiplicationbutton.UseVisualStyleBackColor = true;
            this.showMultiplicationbutton.Click += new System.EventHandler(this.ShowMultiplicationbutton_Click);
            // 
            // showDivisionbutton
            // 
            this.showDivisionbutton.Location = new System.Drawing.Point(503, 235);
            this.showDivisionbutton.Name = "showDivisionbutton";
            this.showDivisionbutton.Size = new System.Drawing.Size(194, 44);
            this.showDivisionbutton.TabIndex = 17;
            this.showDivisionbutton.Text = "Show Operation";
            this.showDivisionbutton.UseVisualStyleBackColor = true;
            this.showDivisionbutton.Click += new System.EventHandler(this.ShowDivisionbutton_Click);
            // 
            // showModulousbutton
            // 
            this.showModulousbutton.Location = new System.Drawing.Point(503, 297);
            this.showModulousbutton.Name = "showModulousbutton";
            this.showModulousbutton.Size = new System.Drawing.Size(194, 44);
            this.showModulousbutton.TabIndex = 18;
            this.showModulousbutton.Text = "Show Operation";
            this.showModulousbutton.UseVisualStyleBackColor = true;
            this.showModulousbutton.Click += new System.EventHandler(this.ShowModulousbutton_Click);
            // 
            // showincreasebutton
            // 
            this.showincreasebutton.Location = new System.Drawing.Point(503, 362);
            this.showincreasebutton.Name = "showincreasebutton";
            this.showincreasebutton.Size = new System.Drawing.Size(194, 49);
            this.showincreasebutton.TabIndex = 19;
            this.showincreasebutton.Text = "Show Operation";
            this.showincreasebutton.UseVisualStyleBackColor = true;
            this.showincreasebutton.Click += new System.EventHandler(this.Showincreasebutton_Click);
            // 
            // showdecreasebutton
            // 
            this.showdecreasebutton.Location = new System.Drawing.Point(503, 429);
            this.showdecreasebutton.Name = "showdecreasebutton";
            this.showdecreasebutton.Size = new System.Drawing.Size(194, 47);
            this.showdecreasebutton.TabIndex = 20;
            this.showdecreasebutton.Text = "Show Operation";
            this.showdecreasebutton.UseVisualStyleBackColor = true;
            this.showdecreasebutton.Click += new System.EventHandler(this.Showdecreasebutton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(377, 506);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(183, 76);
            this.exitButton.TabIndex = 21;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(132, 506);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(171, 76);
            this.clearButton.TabIndex = 22;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.ClearButton_Click);
            // 
            // arithmeticOperations
            // 
            this.AcceptButton = this.clearButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.exitButton;
            this.ClientSize = new System.Drawing.Size(735, 603);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.showdecreasebutton);
            this.Controls.Add(this.showincreasebutton);
            this.Controls.Add(this.showModulousbutton);
            this.Controls.Add(this.showDivisionbutton);
            this.Controls.Add(this.showMultiplicationbutton);
            this.Controls.Add(this.showSubtractionbutton);
            this.Controls.Add(this.showAdditionbutton);
            this.Controls.Add(this.incrementDecreasetextbox);
            this.Controls.Add(this.incrementIncreasetextbox);
            this.Controls.Add(this.modulousTextbox);
            this.Controls.Add(this.divisionTextbox);
            this.Controls.Add(this.multiplicationTextbox);
            this.Controls.Add(this.subtractionTextbox);
            this.Controls.Add(this.additionTextbox);
            this.Controls.Add(this.decreaseLabelbox);
            this.Controls.Add(this.increaseLabelbox);
            this.Controls.Add(this.modulousLabelbox);
            this.Controls.Add(this.divisionLabelbox);
            this.Controls.Add(this.multiplicationLabelbox);
            this.Controls.Add(this.subtractionLabelbox);
            this.Controls.Add(this.additionLabelbox);
            this.Name = "arithmeticOperations";
            this.Text = "Arithmetic Operations";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label additionLabelbox;
        private System.Windows.Forms.Label subtractionLabelbox;
        private System.Windows.Forms.Label multiplicationLabelbox;
        private System.Windows.Forms.Label divisionLabelbox;
        private System.Windows.Forms.Label modulousLabelbox;
        private System.Windows.Forms.Label increaseLabelbox;
        private System.Windows.Forms.Label decreaseLabelbox;
        private System.Windows.Forms.TextBox additionTextbox;
        private System.Windows.Forms.TextBox subtractionTextbox;
        private System.Windows.Forms.TextBox multiplicationTextbox;
        private System.Windows.Forms.TextBox divisionTextbox;
        private System.Windows.Forms.TextBox modulousTextbox;
        private System.Windows.Forms.TextBox incrementIncreasetextbox;
        private System.Windows.Forms.TextBox incrementDecreasetextbox;
        private System.Windows.Forms.Button showAdditionbutton;
        private System.Windows.Forms.Button showSubtractionbutton;
        private System.Windows.Forms.Button showMultiplicationbutton;
        private System.Windows.Forms.Button showDivisionbutton;
        private System.Windows.Forms.Button showModulousbutton;
        private System.Windows.Forms.Button showincreasebutton;
        private System.Windows.Forms.Button showdecreasebutton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button clearButton;
    }
}

