﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/***************************************************************
* Name        : StringVariableDemoHale
* Author      : Cody Hale
* Created     : 09/03/2019
* Course      : CIS 169 - C#
* Version     : 1.0
* OS          : Windows 10
* Copyright   : This is my own original work based on            *               specifications issued by our instructor
* Description : Displays the full name of what the user inputs
*               Input:  First and last name
*               Output: First and last name
* Academic Honesty: I attest that this is my original work.
* I have not used unauthorized source code, either modified or * * unmodified. I have not given other fellow student(s) access to * my program.         
***************************************************************/

namespace StringVariableDemoHale
{
    public partial class StringVariableDemo : Form
    {
        public StringVariableDemo()
        {
            InitializeComponent();
        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }
        /**************************************************************
* Name: string output
* Description: outputs the string entered
* Input: firstNametextbox and lastNametextbox, …
* Output: string of first jname and last name concentation …
***************************************************************/
        private void SubmitButton_Click(object sender, EventArgs e)
        {
            string output;
            output = firstNametextbox.Text + " " +
                lastNametextbox.Text + " ";

            fullNameoutput.Text = output;

        }

        /**************************************************************
* Name: close application
* Description: closes the application
* Input:  …
* Output: …
***************************************************************/
        private void ExitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
