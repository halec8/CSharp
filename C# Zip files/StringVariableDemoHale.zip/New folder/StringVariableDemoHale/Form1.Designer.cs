﻿namespace StringVariableDemoHale
{
    partial class StringVariableDemo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.firstNamelabel = new System.Windows.Forms.Label();
            this.lastNamelabel = new System.Windows.Forms.Label();
            this.fullNamelabel = new System.Windows.Forms.Label();
            this.fullNameoutput = new System.Windows.Forms.Label();
            this.submitButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.firstNametextbox = new System.Windows.Forms.TextBox();
            this.lastNametextbox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // firstNamelabel
            // 
            this.firstNamelabel.AutoSize = true;
            this.firstNamelabel.Location = new System.Drawing.Point(71, 57);
            this.firstNamelabel.Name = "firstNamelabel";
            this.firstNamelabel.Size = new System.Drawing.Size(211, 25);
            this.firstNamelabel.TabIndex = 0;
            this.firstNamelabel.Text = "Enter your first name";
            // 
            // lastNamelabel
            // 
            this.lastNamelabel.AutoSize = true;
            this.lastNamelabel.Location = new System.Drawing.Point(76, 165);
            this.lastNamelabel.Name = "lastNamelabel";
            this.lastNamelabel.Size = new System.Drawing.Size(210, 25);
            this.lastNamelabel.TabIndex = 1;
            this.lastNamelabel.Text = "Enter your last name";
            // 
            // fullNamelabel
            // 
            this.fullNamelabel.AutoSize = true;
            this.fullNamelabel.Location = new System.Drawing.Point(76, 272);
            this.fullNamelabel.Name = "fullNamelabel";
            this.fullNamelabel.Size = new System.Drawing.Size(173, 25);
            this.fullNamelabel.TabIndex = 2;
            this.fullNamelabel.Text = "Your full name is";
            // 
            // fullNameoutput
            // 
            this.fullNameoutput.AutoSize = true;
            this.fullNameoutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fullNameoutput.Location = new System.Drawing.Point(315, 270);
            this.fullNameoutput.Name = "fullNameoutput";
            this.fullNameoutput.Size = new System.Drawing.Size(2, 27);
            this.fullNameoutput.TabIndex = 3;
            this.fullNameoutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // submitButton
            // 
            this.submitButton.Location = new System.Drawing.Point(76, 360);
            this.submitButton.Name = "submitButton";
            this.submitButton.Size = new System.Drawing.Size(161, 58);
            this.submitButton.TabIndex = 4;
            this.submitButton.Text = "Submit";
            this.submitButton.UseVisualStyleBackColor = true;
            this.submitButton.Click += new System.EventHandler(this.SubmitButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.exitButton.Location = new System.Drawing.Point(345, 360);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(124, 57);
            this.exitButton.TabIndex = 5;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // firstNametextbox
            // 
            this.firstNametextbox.Location = new System.Drawing.Point(315, 50);
            this.firstNametextbox.Name = "firstNametextbox";
            this.firstNametextbox.Size = new System.Drawing.Size(171, 31);
            this.firstNametextbox.TabIndex = 6;
            this.firstNametextbox.TextChanged += new System.EventHandler(this.TextBox1_TextChanged);
            // 
            // lastNametextbox
            // 
            this.lastNametextbox.Location = new System.Drawing.Point(315, 165);
            this.lastNametextbox.Name = "lastNametextbox";
            this.lastNametextbox.Size = new System.Drawing.Size(171, 31);
            this.lastNametextbox.TabIndex = 7;
            // 
            // StringVariableDemo
            // 
            this.AcceptButton = this.submitButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.exitButton;
            this.ClientSize = new System.Drawing.Size(525, 458);
            this.Controls.Add(this.lastNametextbox);
            this.Controls.Add(this.firstNametextbox);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.submitButton);
            this.Controls.Add(this.fullNameoutput);
            this.Controls.Add(this.fullNamelabel);
            this.Controls.Add(this.lastNamelabel);
            this.Controls.Add(this.firstNamelabel);
            this.Name = "StringVariableDemo";
            this.Text = "String Variable Demo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label firstNamelabel;
        private System.Windows.Forms.Label lastNamelabel;
        private System.Windows.Forms.Label fullNamelabel;
        private System.Windows.Forms.Label fullNameoutput;
        private System.Windows.Forms.Button submitButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.TextBox firstNametextbox;
        private System.Windows.Forms.TextBox lastNametextbox;
    }
}

