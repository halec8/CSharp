﻿using System;
using System.Data;
using System.Windows.Forms;
using Your_Attendance.DataSet1TableAdapters;

namespace Your_Attendance
{

    /***************************************************************
* Name        : Login
* Author      : Cody Hale
* Created     : 12/1/2019
***************************************************************/
    public partial class Login : Form
    {
        // Creates a flag for login
        public bool loginFlag { get; set; }

        // Gets the UserID
        public int UserID { get; set; }

        public Login()
        {
            InitializeComponent();
            loginFlag = false;
        }


        /**************************************************************
* Name: loginButton_Click
* Description: checks to see if the username/password match a username/password within the database
         * If it does then login is successful and if it doens't login isn't successful. A message is displayed in both scenarios
* Input: username/password
* Output: Message 
***************************************************************/

        private void loginButton_Click(object sender, EventArgs e)
        {
            DataSet1TableAdapters.LoginTBLTableAdapter userLogin = new LoginTBLTableAdapter();
            DataTable dt = userLogin.GetDataByUserAndPassword(usernameTextBox.Text, passwordTextBox.Text);

            if (dt.Rows.Count > 0)
            {
                //Valid
                loginFlag = true;
                MessageBox.Show("Login successful!");
                UserID = int.Parse(dt.Rows[0]["UserID"].ToString());
                Close();
            }
            else
            {
                // NOT VALID
                loginFlag = false;
                passwordTextBox.Text = "";
                usernameTextBox.Focus();
                MessageBox.Show("Login failed due to invalid Username and Password. Please try again.");
            }
        }

        /**************************************************************
* Name: exitButton_Click
* Description: closes the application
***************************************************************/
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}