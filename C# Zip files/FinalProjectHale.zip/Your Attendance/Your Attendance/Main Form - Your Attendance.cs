﻿using MetroFramework.Forms;
using System;
using System.Data;
using System.IO;
using System.Windows.Forms;
using Your_Attendance.DataSet1TableAdapters;

/***************************************************************
* Name        : Your Attendance
* Author      : Cody Hale
* Created     : 12/1/2019
* Course      : CIS 169 - C#
* Version     : 1.0
* OS          : Windows XX
* Copyright   : This is my own original work based on            *               specifications issued by our instructor
* Description : Has a interface that allows a user to login, create classes, add students, update their status for the specific day and generate reports on attendance based upon a specific month.
 *              The user is able to save all data and pull all date from a SQL database.
*               Input:  Class, student, presence
*               Output: Class, student, presence, reports
* Academic Honesty: I attest that this is my original work.
* I have not used unauthorized source code, either modified or * * unmodified. I have not given other fellow student(s) access to * my program.         
***************************************************************/


namespace Your_Attendance
{

    /***************************************************************
* Name        : YourAttendance
* Author      : Cody Hale
* Created     : 12/1/2019
***************************************************************/


    public partial class YourAttendance : MetroForm
    {
        public YourAttendance()
        {
            InitializeComponent();
            LoggedIn = 0;
        }


        // Gets the LoggedIn state
        public int LoggedIn { get; set; }

        // Gets the UserID
        public int UserID { get; set; }

        /**************************************************************
* Name: YourAttendance_Load
* Description: Fills the Records table adapter on load
***************************************************************/

        private void YourAttendance_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dataSet1.RecordsTBL' table. You can move, or remove it, as needed.
            RecordsTBLTableAdapter.Fill(dataSet1.RecordsTBL);
            // TODO: This line of code loads data into the 'dataSet1.ClassTBL' table. You can move, or remove it, as needed.
        }

        /**************************************************************
* Name: YourAttendance_Activated
* Description: Once the form is activated it displays the Id that is logged in
***************************************************************/

        private void YourAttendance_Activated(object sender, EventArgs e)
        {
            if (LoggedIn == 0)
            {
                var newLogin = new Login();
                newLogin.ShowDialog();

                if (newLogin.loginFlag == false)
                {
                    Close();
                }
                else
                {
                    UserID = newLogin.UserID;
                    loggedInUserDisplayLabel.Text = UserID.ToString();
                    classTBLTableAdapter.Fill(dataSet1.ClassTBL);
                    classTBLBindingSource.Filter = "UserID = '" + UserID + "'";
                    LoggedIn = 1;
                }
            }
        }

        /**************************************************************
     * Name: addClassButton_Click
     * Description: Shows the AddClass form
     ***************************************************************/

        private void addClassButton_Click(object sender, EventArgs e)
        {
            var addClass = new Add_Class();
            addClass.UserID = UserID;
            addClass.ShowDialog();
        }


        /**************************************************************
* Name: addStudentButton_Click
* Description: 
* Input: int/string/etc… , int/string/etc… field1, …
* Output: int/string/etc…, int/string/etc… field1, …
***************************************************************/


        private void addStudentButton_Click(object sender, EventArgs e)
        {
            var myStudent = new Add_Student();
            myStudent.ClassName = selectAClassComboBox.Text;
            myStudent.ClassID = (int) selectAClassComboBox.SelectedValue;
            myStudent.ShowDialog();
        }

        /**************************************************************
* Name: exitButton_Click
* Description: Exits the application
***************************************************************/
        private void exitButton_Click(object sender, EventArgs e)
        {
            Close();
        }

        /**************************************************************
* Name: reportsButton_Click
* Description: Checks for records and determines if records exist. If they do then its appended.
         * If no records exist new records are created. 
***************************************************************/

        private void reportsButton_Click(object sender, EventArgs e)
        {
            //Checks for records, if some exist we append. If no records exist we create new records

            var myRecords = new RecordsTBLTableAdapter();
            DataTable dt =
                myRecords.GetDataByClassIDAndDateAttendance((int) selectAClassComboBox.SelectedValue,
                    myDateTimePicker.Text);

            if (dt.Rows.Count > 0)
            {
                // records exist and can be edited
                DataTable newDt =
                    myRecords.GetDataByClassIDAndDateAttendance((int) selectAClassComboBox.SelectedValue,
                        myDateTimePicker.Text);
                reportGridView.DataSource = newDt;
            }
            else
            {
                // creates records for each student
                var studentsAdapter = new StudentTBLTableAdapter();

                DataTable dtStudentsInfo = studentsAdapter.GetDataByClassID((int) selectAClassComboBox.SelectedValue);

                foreach (DataRow row in dtStudentsInfo.Rows)
                    // inserts new data for the records of a student

                    myRecords.RecordsInsertQuery((int) row[0], (int) selectAClassComboBox.SelectedValue,
                        myDateTimePicker.Text, "", row[1].ToString(), selectAClassComboBox.Text);

                DataTable newDt =
                    myRecords.GetDataByClassIDAndDateAttendance((int) selectAClassComboBox.SelectedValue,
                        myDateTimePicker.Text);
                reportGridView.DataSource = newDt;
            }

            RecordsTBLTableAdapter.Fill(dataSet1.RecordsTBL);
        }

        /**************************************************************
* Name: clearButton_Click
* Description: clears the datagrid
***************************************************************/

        private void clearButton_Click(object sender, EventArgs e)
        {
            var myRecords = new RecordsTBLTableAdapter();

            foreach (DataGridViewRow row in reportGridView.Rows)
            {
                if (row.Cells[1].Value != null)
                {
                    myRecords.StatusUpdateQuery("", row.Cells[1].Value.ToString(),
                        (int) selectAClassComboBox.SelectedValue, myDateTimePicker.Text);
                }
            }

            DataTable newDt =
                myRecords.GetDataByClassIDAndDateAttendance((int) selectAClassComboBox.SelectedValue,
                    myDateTimePicker.Text);
            reportGridView.DataSource = newDt;
        }


        /**************************************************************
* Name: saveButton_Click
* Description: Saves the entered data within the datagrid to the database
***************************************************************/

        private void saveButton_Click(object sender, EventArgs e)
        {
            RecordsTBLTableAdapter myRecords = new RecordsTBLTableAdapter();

            foreach (DataGridViewRow row in reportGridView.Rows)
            {
                if (row.Cells[0].Value != null)
                {
                    myRecords.StatusUpdateQuery(row.Cells[1].Value.ToString(), row.Cells[0].Value.ToString(),
                        (int) selectAClassComboBox.SelectedValue, myDateTimePicker.Text);
                }
            }

            DataTable newDt =
                myRecords.GetDataByClassIDAndDateAttendance((int) selectAClassComboBox.SelectedValue,
                    myDateTimePicker.Text);
            reportGridView.DataSource = newDt;
        }

        /**************************************************************
* Name: exitToolStripMenueItem_Click
* Description: closes the application from the tool strip menu
***************************************************************/
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /**************************************************************
* Name: manualToolStripMenuItem_Click
* Description: opens a messagebox that displays the readme/manual.
***************************************************************/

        private void manualToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string readme;
            StreamReader inputfile;
            inputfile = File.OpenText("MANUAL README.txt");
            readme = inputfile.ReadToEnd();
            MessageBox.Show(readme);
        }

        /**************************************************************
* Name: helpToolStripMenuItem_Click
* Description: Creates a messagebox that displays information to help the user.
***************************************************************/

        private void helpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("For more information on how to use the application, please open the manual. " +
                            "You can do this by clicking the manual button below for additional assistance.");
        }

        /**************************************************************
* Name: registerButton_Click
* Description: Opens the registration form
***************************************************************/

        private void registerButton_Click(object sender, EventArgs e)
        {
            Registration newRegistration = new Registration();
            newRegistration.ShowDialog();
        }

        /**************************************************************
* Name: getReportsOnReportsPageButton_Click
* Description: Pulls reports for each student and displays the data in the listview
***************************************************************/

        private void getReportsOnReportsPageButton_Click(object sender, EventArgs e)
        {
            var studentsAdapter = new StudentTBLTableAdapter();

            DataTable dtStudentsInfo = studentsAdapter.GetDataByClassID((int) selectClassForReports.SelectedValue);

            var records = new RecordsTBL1TableAdapter();


            try
            {
                var allData = records.GetDataByMyRecords().Rows;
                foreach (DataRow row in allData)
                {
                    var newReportsListView = new ListViewItem();
                    newReportsListView.Text = row[5].ToString();
                    newReportsListView.SubItems.Add(row[4].ToString());
                    newReportsListView.SubItems.Add(row[6].ToString());
                    reportsListView.Items.Add(newReportsListView);
                }
            }
            catch (Exception exception)
            {
                throw;
            }
        }
    }
}