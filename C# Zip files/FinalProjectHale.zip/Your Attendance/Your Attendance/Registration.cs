﻿using System;
using System.Windows.Forms;
using Your_Attendance.DataSet1TableAdapters;

namespace Your_Attendance
{
    /***************************************************************
* Name        : Registration
* Author      : Cody Hale
* Created     : 12/1/2019
***************************************************************/
    public partial class Registration : Form
    {
        public Registration()
        {
            InitializeComponent();
        }


        /**************************************************************
* Name: registrationSubmitButton_Click
* Description: submits the username/password to the database so it can be used on future logins. If the criteria isn't valid an error message is produced
         * If the passwords match then its successfully submitted.
***************************************************************/


        private void registrationSubmitButton_Click(object sender, EventArgs e)
        {
            DataSet1TableAdapters.LoginTBLTableAdapter myRegistration = new LoginTBLTableAdapter();

            if (registrationPasswordTextBox.Text != confirmPassTextBox.Text)
            {
                MessageBox.Show("Passwords don't match, please re-enter a password");
                return;
            }
            else
            {
                myRegistration.RegistrationQuery(registrationUserName.Text, registrationPasswordTextBox.Text);

                MessageBox.Show("Successful, please exit the application and log back in with the registered username and password");

                Close();
            }
        }

        /**************************************************************
* Name: registrationExitButton_Click
* Description: Closes the application
***************************************************************/
        private void registrationExitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}