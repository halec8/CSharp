﻿namespace Your_Attendance
{
    partial class Add_Class
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.addClassTextBox = new MetroFramework.Controls.MetroTextBox();
            this.addClassPromptLabel = new MetroFramework.Controls.MetroLabel();
            this.exitButton = new MetroFramework.Controls.MetroButton();
            this.submitButton = new MetroFramework.Controls.MetroButton();
            this.SuspendLayout();
            // 
            // addClassTextBox
            // 
            this.addClassTextBox.Location = new System.Drawing.Point(154, 163);
            this.addClassTextBox.Name = "addClassTextBox";
            this.addClassTextBox.Size = new System.Drawing.Size(450, 35);
            this.addClassTextBox.TabIndex = 0;
            // 
            // addClassPromptLabel
            // 
            this.addClassPromptLabel.AutoSize = true;
            this.addClassPromptLabel.Location = new System.Drawing.Point(154, 107);
            this.addClassPromptLabel.Name = "addClassPromptLabel";
            this.addClassPromptLabel.Size = new System.Drawing.Size(70, 19);
            this.addClassPromptLabel.TabIndex = 1;
            this.addClassPromptLabel.Text = "Add Class:";
            // 
            // exitButton
            // 
            this.exitButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.exitButton.Location = new System.Drawing.Point(409, 273);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(211, 63);
            this.exitButton.TabIndex = 2;
            this.exitButton.Text = "E&xit";
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // submitButton
            // 
            this.submitButton.Location = new System.Drawing.Point(141, 273);
            this.submitButton.Name = "submitButton";
            this.submitButton.Size = new System.Drawing.Size(211, 63);
            this.submitButton.TabIndex = 3;
            this.submitButton.Text = "S&ubmit";
            this.submitButton.Click += new System.EventHandler(this.submitButton_Click);
            // 
            // Add_Class
            // 
            this.AcceptButton = this.submitButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.CancelButton = this.exitButton;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.submitButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.addClassPromptLabel);
            this.Controls.Add(this.addClassTextBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Add_Class";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add Class";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroTextBox addClassTextBox;
        private MetroFramework.Controls.MetroLabel addClassPromptLabel;
        private MetroFramework.Controls.MetroButton exitButton;
        private MetroFramework.Controls.MetroButton submitButton;
    }
}