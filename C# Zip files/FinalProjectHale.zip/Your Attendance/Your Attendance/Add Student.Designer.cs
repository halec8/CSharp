﻿namespace Your_Attendance
{
    partial class Add_Student
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.classNamePromptLabel = new MetroFramework.Controls.MetroLabel();
            this.classNameDisplayLabel = new MetroFramework.Controls.MetroLabel();
            this.classIdDisplayLabel = new MetroFramework.Controls.MetroLabel();
            this.classIdPromptLabel = new MetroFramework.Controls.MetroLabel();
            this.saveButton = new MetroFramework.Controls.MetroButton();
            this.exitButton = new MetroFramework.Controls.MetroButton();
            this.studentIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.studentNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.classIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.studentTBLBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet1 = new Your_Attendance.DataSet1();
            this.studentTBLTableAdapter = new Your_Attendance.DataSet1TableAdapters.StudentTBLTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentTBLBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.studentIDDataGridViewTextBoxColumn,
            this.studentNameDataGridViewTextBoxColumn,
            this.classIDDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.studentTBLBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(34, 123);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 82;
            this.dataGridView1.RowTemplate.Height = 33;
            this.dataGridView1.Size = new System.Drawing.Size(940, 283);
            this.dataGridView1.TabIndex = 0;
            // 
            // classNamePromptLabel
            // 
            this.classNamePromptLabel.AutoSize = true;
            this.classNamePromptLabel.Location = new System.Drawing.Point(49, 56);
            this.classNamePromptLabel.Name = "classNamePromptLabel";
            this.classNamePromptLabel.Size = new System.Drawing.Size(81, 19);
            this.classNamePromptLabel.TabIndex = 1;
            this.classNamePromptLabel.Text = "Class Name:";
            // 
            // classNameDisplayLabel
            // 
            this.classNameDisplayLabel.AutoSize = true;
            this.classNameDisplayLabel.Location = new System.Drawing.Point(207, 56);
            this.classNameDisplayLabel.Name = "classNameDisplayLabel";
            this.classNameDisplayLabel.Size = new System.Drawing.Size(0, 0);
            this.classNameDisplayLabel.TabIndex = 2;
            // 
            // classIdDisplayLabel
            // 
            this.classIdDisplayLabel.AutoSize = true;
            this.classIdDisplayLabel.Location = new System.Drawing.Point(815, 56);
            this.classIdDisplayLabel.Name = "classIdDisplayLabel";
            this.classIdDisplayLabel.Size = new System.Drawing.Size(0, 0);
            this.classIdDisplayLabel.TabIndex = 4;
            // 
            // classIdPromptLabel
            // 
            this.classIdPromptLabel.AutoSize = true;
            this.classIdPromptLabel.Location = new System.Drawing.Point(700, 56);
            this.classIdPromptLabel.Name = "classIdPromptLabel";
            this.classIdPromptLabel.Size = new System.Drawing.Size(57, 19);
            this.classIdPromptLabel.TabIndex = 3;
            this.classIdPromptLabel.Text = "Class ID:";
            // 
            // saveButton
            // 
            this.saveButton.Location = new System.Drawing.Point(186, 456);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(214, 65);
            this.saveButton.TabIndex = 5;
            this.saveButton.Text = "S&ave";
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.exitButton.Location = new System.Drawing.Point(618, 457);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(187, 64);
            this.exitButton.TabIndex = 6;
            this.exitButton.Text = "E&xit";
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // studentIDDataGridViewTextBoxColumn
            // 
            this.studentIDDataGridViewTextBoxColumn.DataPropertyName = "StudentID";
            this.studentIDDataGridViewTextBoxColumn.HeaderText = "StudentID";
            this.studentIDDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.studentIDDataGridViewTextBoxColumn.Name = "studentIDDataGridViewTextBoxColumn";
            this.studentIDDataGridViewTextBoxColumn.Width = 200;
            // 
            // studentNameDataGridViewTextBoxColumn
            // 
            this.studentNameDataGridViewTextBoxColumn.DataPropertyName = "StudentName";
            this.studentNameDataGridViewTextBoxColumn.HeaderText = "StudentName";
            this.studentNameDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.studentNameDataGridViewTextBoxColumn.Name = "studentNameDataGridViewTextBoxColumn";
            this.studentNameDataGridViewTextBoxColumn.Width = 200;
            // 
            // classIDDataGridViewTextBoxColumn
            // 
            this.classIDDataGridViewTextBoxColumn.DataPropertyName = "ClassID";
            this.classIDDataGridViewTextBoxColumn.HeaderText = "ClassID";
            this.classIDDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.classIDDataGridViewTextBoxColumn.Name = "classIDDataGridViewTextBoxColumn";
            this.classIDDataGridViewTextBoxColumn.Width = 200;
            // 
            // studentTBLBindingSource
            // 
            this.studentTBLBindingSource.DataMember = "StudentTBL";
            this.studentTBLBindingSource.DataSource = this.dataSet1;
            // 
            // dataSet1
            // 
            this.dataSet1.DataSetName = "DataSet1";
            this.dataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // studentTBLTableAdapter
            // 
            this.studentTBLTableAdapter.ClearBeforeFill = true;
            // 
            // Add_Student
            // 
            this.AcceptButton = this.saveButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.CancelButton = this.exitButton;
            this.ClientSize = new System.Drawing.Size(1032, 561);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.saveButton);
            this.Controls.Add(this.classIdDisplayLabel);
            this.Controls.Add(this.classIdPromptLabel);
            this.Controls.Add(this.classNameDisplayLabel);
            this.Controls.Add(this.classNamePromptLabel);
            this.Controls.Add(this.dataGridView1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Add_Student";
            this.Text = "Add Student";
            this.Load += new System.EventHandler(this.Add_Student_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentTBLBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private MetroFramework.Controls.MetroLabel classNamePromptLabel;
        private MetroFramework.Controls.MetroLabel classNameDisplayLabel;
        private MetroFramework.Controls.MetroLabel classIdDisplayLabel;
        private MetroFramework.Controls.MetroLabel classIdPromptLabel;
        private MetroFramework.Controls.MetroButton saveButton;
        private MetroFramework.Controls.MetroButton exitButton;
        private DataSet1 dataSet1;
        private System.Windows.Forms.BindingSource studentTBLBindingSource;
        private DataSet1TableAdapters.StudentTBLTableAdapter studentTBLTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn studentIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn studentNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn classIDDataGridViewTextBoxColumn;
    }
}