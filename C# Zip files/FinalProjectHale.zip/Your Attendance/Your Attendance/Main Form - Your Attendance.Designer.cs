﻿namespace Your_Attendance
{
    partial class YourAttendance
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.yourAttendanceTabControl = new MetroFramework.Controls.MetroTabControl();
            this.Attendance = new MetroFramework.Controls.MetroTabPage();
            this.registerButton = new MetroFramework.Controls.MetroButton();
            this.exitButton = new MetroFramework.Controls.MetroButton();
            this.selectDatePromptLabel = new MetroFramework.Controls.MetroLabel();
            this.selectClassPromptLabel = new MetroFramework.Controls.MetroLabel();
            this.reportsButton = new MetroFramework.Controls.MetroButton();
            this.selectAClassComboBox = new MetroFramework.Controls.MetroComboBox();
            this.classTBLBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet1 = new Your_Attendance.DataSet1();
            this.addStudentButton = new MetroFramework.Controls.MetroButton();
            this.myDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.clearButton = new MetroFramework.Controls.MetroButton();
            this.reportGridView = new System.Windows.Forms.DataGridView();
            this.studentNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statusDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.recordsTBLBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.addClassButton = new MetroFramework.Controls.MetroButton();
            this.saveButton = new MetroFramework.Controls.MetroButton();
            this.Reports = new MetroFramework.Controls.MetroTabPage();
            this.ReportsDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.reportsListView = new System.Windows.Forms.ListView();
            this.studentColumn = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.presentColumn = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.absenceColumn = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.getReportsOnReportsPageButton = new MetroFramework.Controls.MetroButton();
            this.selectClassForReports = new MetroFramework.Controls.MetroComboBox();
            this.loggedInUserStatusBar = new System.Windows.Forms.StatusStrip();
            this.userStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.userStatusDisplayLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.loggedInUserDisplayLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.dataSet1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.classTBLTableAdapter = new Your_Attendance.DataSet1TableAdapters.ClassTBLTableAdapter();
            this.RecordsTBLTableAdapter = new Your_Attendance.DataSet1TableAdapters.RecordsTBLTableAdapter();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.optionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.manualToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.yourAttendanceTabControl.SuspendLayout();
            this.Attendance.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.classTBLBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.reportGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.recordsTBLBindingSource)).BeginInit();
            this.Reports.SuspendLayout();
            this.loggedInUserStatusBar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1BindingSource)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // yourAttendanceTabControl
            // 
            this.yourAttendanceTabControl.Controls.Add(this.Attendance);
            this.yourAttendanceTabControl.Controls.Add(this.Reports);
            this.yourAttendanceTabControl.Location = new System.Drawing.Point(33, 101);
            this.yourAttendanceTabControl.Name = "yourAttendanceTabControl";
            this.yourAttendanceTabControl.SelectedIndex = 0;
            this.yourAttendanceTabControl.Size = new System.Drawing.Size(1059, 1156);
            this.yourAttendanceTabControl.TabIndex = 0;
            this.yourAttendanceTabControl.Tag = "Attendance";
            // 
            // Attendance
            // 
            this.Attendance.BackColor = System.Drawing.Color.White;
            this.Attendance.Controls.Add(this.registerButton);
            this.Attendance.Controls.Add(this.exitButton);
            this.Attendance.Controls.Add(this.selectDatePromptLabel);
            this.Attendance.Controls.Add(this.selectClassPromptLabel);
            this.Attendance.Controls.Add(this.reportsButton);
            this.Attendance.Controls.Add(this.selectAClassComboBox);
            this.Attendance.Controls.Add(this.addStudentButton);
            this.Attendance.Controls.Add(this.myDateTimePicker);
            this.Attendance.Controls.Add(this.clearButton);
            this.Attendance.Controls.Add(this.reportGridView);
            this.Attendance.Controls.Add(this.addClassButton);
            this.Attendance.Controls.Add(this.saveButton);
            this.Attendance.HorizontalScrollbarBarColor = true;
            this.Attendance.Location = new System.Drawing.Point(8, 42);
            this.Attendance.Name = "Attendance";
            this.Attendance.Size = new System.Drawing.Size(1043, 1106);
            this.Attendance.TabIndex = 0;
            this.Attendance.Text = "Attendance";
            this.Attendance.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Attendance.VerticalScrollbarBarColor = true;
            // 
            // registerButton
            // 
            this.registerButton.Location = new System.Drawing.Point(730, 1005);
            this.registerButton.Name = "registerButton";
            this.registerButton.Size = new System.Drawing.Size(211, 77);
            this.registerButton.TabIndex = 12;
            this.registerButton.Text = "Register";
            this.registerButton.Click += new System.EventHandler(this.registerButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.exitButton.Location = new System.Drawing.Point(729, 846);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(212, 70);
            this.exitButton.TabIndex = 11;
            this.exitButton.Text = "E&xit";
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // selectDatePromptLabel
            // 
            this.selectDatePromptLabel.AutoSize = true;
            this.selectDatePromptLabel.Location = new System.Drawing.Point(490, 68);
            this.selectDatePromptLabel.Name = "selectDatePromptLabel";
            this.selectDatePromptLabel.Size = new System.Drawing.Size(77, 19);
            this.selectDatePromptLabel.TabIndex = 5;
            this.selectDatePromptLabel.Text = "Select Date:";
            // 
            // selectClassPromptLabel
            // 
            this.selectClassPromptLabel.AutoSize = true;
            this.selectClassPromptLabel.Location = new System.Drawing.Point(33, 68);
            this.selectClassPromptLabel.Name = "selectClassPromptLabel";
            this.selectClassPromptLabel.Size = new System.Drawing.Size(79, 19);
            this.selectClassPromptLabel.TabIndex = 4;
            this.selectClassPromptLabel.Text = "Select Class:";
            // 
            // reportsButton
            // 
            this.reportsButton.Location = new System.Drawing.Point(729, 120);
            this.reportsButton.Name = "reportsButton";
            this.reportsButton.Size = new System.Drawing.Size(212, 70);
            this.reportsButton.TabIndex = 10;
            this.reportsButton.Text = "Reports";
            this.reportsButton.Click += new System.EventHandler(this.reportsButton_Click);
            // 
            // selectAClassComboBox
            // 
            this.selectAClassComboBox.DataSource = this.classTBLBindingSource;
            this.selectAClassComboBox.DisplayMember = "ClassName";
            this.selectAClassComboBox.FormattingEnabled = true;
            this.selectAClassComboBox.ItemHeight = 23;
            this.selectAClassComboBox.Location = new System.Drawing.Point(33, 134);
            this.selectAClassComboBox.Name = "selectAClassComboBox";
            this.selectAClassComboBox.Size = new System.Drawing.Size(350, 29);
            this.selectAClassComboBox.TabIndex = 3;
            this.selectAClassComboBox.ValueMember = "ClassID";
            // 
            // classTBLBindingSource
            // 
            this.classTBLBindingSource.DataMember = "ClassTBL";
            this.classTBLBindingSource.DataSource = this.dataSet1;
            // 
            // dataSet1
            // 
            this.dataSet1.DataSetName = "DataSet1";
            this.dataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // addStudentButton
            // 
            this.addStudentButton.Location = new System.Drawing.Point(620, 402);
            this.addStudentButton.Name = "addStudentButton";
            this.addStudentButton.Size = new System.Drawing.Size(212, 71);
            this.addStudentButton.TabIndex = 7;
            this.addStudentButton.Text = "Add Student";
            this.addStudentButton.Click += new System.EventHandler(this.addStudentButton_Click);
            // 
            // myDateTimePicker
            // 
            this.myDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.myDateTimePicker.Location = new System.Drawing.Point(490, 134);
            this.myDateTimePicker.Name = "myDateTimePicker";
            this.myDateTimePicker.Size = new System.Drawing.Size(200, 31);
            this.myDateTimePicker.TabIndex = 2;
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(620, 701);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(212, 67);
            this.clearButton.TabIndex = 9;
            this.clearButton.Text = "Clear";
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // reportGridView
            // 
            this.reportGridView.AutoGenerateColumns = false;
            this.reportGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.reportGridView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.reportGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.reportGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.studentNameDataGridViewTextBoxColumn,
            this.statusDataGridViewTextBoxColumn});
            this.reportGridView.DataSource = this.recordsTBLBindingSource;
            this.reportGridView.Location = new System.Drawing.Point(0, 225);
            this.reportGridView.Name = "reportGridView";
            this.reportGridView.RowHeadersWidth = 82;
            this.reportGridView.RowTemplate.Height = 33;
            this.reportGridView.Size = new System.Drawing.Size(487, 720);
            this.reportGridView.TabIndex = 1;
            // 
            // studentNameDataGridViewTextBoxColumn
            // 
            this.studentNameDataGridViewTextBoxColumn.DataPropertyName = "StudentName";
            this.studentNameDataGridViewTextBoxColumn.HeaderText = "StudentName";
            this.studentNameDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.studentNameDataGridViewTextBoxColumn.Name = "studentNameDataGridViewTextBoxColumn";
            this.studentNameDataGridViewTextBoxColumn.Width = 187;
            // 
            // statusDataGridViewTextBoxColumn
            // 
            this.statusDataGridViewTextBoxColumn.DataPropertyName = "Status";
            this.statusDataGridViewTextBoxColumn.HeaderText = "Status";
            this.statusDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.statusDataGridViewTextBoxColumn.Name = "statusDataGridViewTextBoxColumn";
            this.statusDataGridViewTextBoxColumn.Width = 118;
            // 
            // recordsTBLBindingSource
            // 
            this.recordsTBLBindingSource.DataMember = "RecordsTBL";
            this.recordsTBLBindingSource.DataSource = this.dataSet1;
            // 
            // addClassButton
            // 
            this.addClassButton.Location = new System.Drawing.Point(620, 265);
            this.addClassButton.Name = "addClassButton";
            this.addClassButton.Size = new System.Drawing.Size(212, 62);
            this.addClassButton.TabIndex = 6;
            this.addClassButton.Text = "Add Class";
            this.addClassButton.Click += new System.EventHandler(this.addClassButton_Click);
            // 
            // saveButton
            // 
            this.saveButton.Location = new System.Drawing.Point(620, 552);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(212, 69);
            this.saveButton.TabIndex = 8;
            this.saveButton.Text = "Save";
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // Reports
            // 
            this.Reports.BackColor = System.Drawing.SystemColors.Control;
            this.Reports.Controls.Add(this.ReportsDateTimePicker);
            this.Reports.Controls.Add(this.reportsListView);
            this.Reports.Controls.Add(this.metroLabel1);
            this.Reports.Controls.Add(this.metroLabel2);
            this.Reports.Controls.Add(this.getReportsOnReportsPageButton);
            this.Reports.Controls.Add(this.selectClassForReports);
            this.Reports.HorizontalScrollbarBarColor = true;
            this.Reports.Location = new System.Drawing.Point(8, 42);
            this.Reports.Name = "Reports";
            this.Reports.Size = new System.Drawing.Size(1043, 1106);
            this.Reports.TabIndex = 1;
            this.Reports.Text = "Reports";
            this.Reports.VerticalScrollbarBarColor = true;
            // 
            // ReportsDateTimePicker
            // 
            this.ReportsDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.ReportsDateTimePicker.Location = new System.Drawing.Point(478, 88);
            this.ReportsDateTimePicker.Name = "ReportsDateTimePicker";
            this.ReportsDateTimePicker.Size = new System.Drawing.Size(200, 31);
            this.ReportsDateTimePicker.TabIndex = 17;
            // 
            // reportsListView
            // 
            this.reportsListView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.studentColumn,
            this.presentColumn,
            this.absenceColumn});
            this.reportsListView.HideSelection = false;
            this.reportsListView.Location = new System.Drawing.Point(51, 173);
            this.reportsListView.Name = "reportsListView";
            this.reportsListView.Size = new System.Drawing.Size(908, 491);
            this.reportsListView.TabIndex = 16;
            this.reportsListView.UseCompatibleStateImageBehavior = false;
            this.reportsListView.View = System.Windows.Forms.View.Details;
            // 
            // studentColumn
            // 
            this.studentColumn.Text = "Student";
            this.studentColumn.Width = 223;
            // 
            // presentColumn
            // 
            this.presentColumn.Text = "Present";
            this.presentColumn.Width = 164;
            // 
            // absenceColumn
            // 
            this.absenceColumn.Text = "Absence";
            this.absenceColumn.Width = 164;
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(478, 22);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(77, 19);
            this.metroLabel1.TabIndex = 14;
            this.metroLabel1.Text = "Select Date:";
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(21, 22);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(79, 19);
            this.metroLabel2.TabIndex = 13;
            this.metroLabel2.Text = "Select Class:";
            // 
            // getReportsOnReportsPageButton
            // 
            this.getReportsOnReportsPageButton.Location = new System.Drawing.Point(717, 74);
            this.getReportsOnReportsPageButton.Name = "getReportsOnReportsPageButton";
            this.getReportsOnReportsPageButton.Size = new System.Drawing.Size(212, 70);
            this.getReportsOnReportsPageButton.TabIndex = 15;
            this.getReportsOnReportsPageButton.Text = "G&et Reports";
            this.getReportsOnReportsPageButton.Click += new System.EventHandler(this.getReportsOnReportsPageButton_Click);
            // 
            // selectClassForReports
            // 
            this.selectClassForReports.DataSource = this.classTBLBindingSource;
            this.selectClassForReports.DisplayMember = "ClassName";
            this.selectClassForReports.FormattingEnabled = true;
            this.selectClassForReports.ItemHeight = 23;
            this.selectClassForReports.Location = new System.Drawing.Point(21, 88);
            this.selectClassForReports.Name = "selectClassForReports";
            this.selectClassForReports.Size = new System.Drawing.Size(350, 29);
            this.selectClassForReports.TabIndex = 12;
            this.selectClassForReports.ValueMember = "ClassID";
            // 
            // loggedInUserStatusBar
            // 
            this.loggedInUserStatusBar.BackColor = System.Drawing.Color.White;
            this.loggedInUserStatusBar.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.loggedInUserStatusBar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.userStatusLabel,
            this.userStatusDisplayLabel,
            this.loggedInUserDisplayLabel});
            this.loggedInUserStatusBar.Location = new System.Drawing.Point(20, 1298);
            this.loggedInUserStatusBar.Name = "loggedInUserStatusBar";
            this.loggedInUserStatusBar.Size = new System.Drawing.Size(1089, 42);
            this.loggedInUserStatusBar.TabIndex = 1;
            this.loggedInUserStatusBar.Text = "statusStrip1";
            // 
            // userStatusLabel
            // 
            this.userStatusLabel.Name = "userStatusLabel";
            this.userStatusLabel.Size = new System.Drawing.Size(74, 32);
            this.userStatusLabel.Text = "User: ";
            // 
            // userStatusDisplayLabel
            // 
            this.userStatusDisplayLabel.Name = "userStatusDisplayLabel";
            this.userStatusDisplayLabel.Size = new System.Drawing.Size(0, 32);
            // 
            // loggedInUserDisplayLabel
            // 
            this.loggedInUserDisplayLabel.Name = "loggedInUserDisplayLabel";
            this.loggedInUserDisplayLabel.Size = new System.Drawing.Size(0, 32);
            // 
            // dataSet1BindingSource
            // 
            this.dataSet1BindingSource.DataSource = this.dataSet1;
            this.dataSet1BindingSource.Position = 0;
            // 
            // classTBLTableAdapter
            // 
            this.classTBLTableAdapter.ClearBeforeFill = true;
            // 
            // RecordsTBLTableAdapter
            // 
            this.RecordsTBLTableAdapter.ClearBeforeFill = true;
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.White;
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.optionsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(20, 30);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1089, 42);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // optionsToolStripMenuItem
            // 
            this.optionsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.helpToolStripMenuItem,
            this.manualToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.optionsToolStripMenuItem.Name = "optionsToolStripMenuItem";
            this.optionsToolStripMenuItem.Size = new System.Drawing.Size(119, 38);
            this.optionsToolStripMenuItem.Text = "Options";
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(229, 44);
            this.helpToolStripMenuItem.Text = "Help";
            this.helpToolStripMenuItem.Click += new System.EventHandler(this.helpToolStripMenuItem_Click);
            // 
            // manualToolStripMenuItem
            // 
            this.manualToolStripMenuItem.Name = "manualToolStripMenuItem";
            this.manualToolStripMenuItem.Size = new System.Drawing.Size(229, 44);
            this.manualToolStripMenuItem.Text = "Manual";
            this.manualToolStripMenuItem.Click += new System.EventHandler(this.manualToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(229, 44);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // YourAttendance
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.CancelButton = this.exitButton;
            this.ClientSize = new System.Drawing.Size(1129, 1360);
            this.Controls.Add(this.loggedInUserStatusBar);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.yourAttendanceTabControl);
            this.DisplayHeader = false;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.HelpButton = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "YourAttendance";
            this.Padding = new System.Windows.Forms.Padding(20, 30, 20, 20);
            this.ShadowType = MetroFramework.Forms.MetroForm.MetroFormShadowType.SystemShadow;
            this.Text = "Your Attendance Attendance Program";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Activated += new System.EventHandler(this.YourAttendance_Activated);
            this.Load += new System.EventHandler(this.YourAttendance_Load);
            this.yourAttendanceTabControl.ResumeLayout(false);
            this.Attendance.ResumeLayout(false);
            this.Attendance.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.classTBLBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.reportGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.recordsTBLBindingSource)).EndInit();
            this.Reports.ResumeLayout(false);
            this.Reports.PerformLayout();
            this.loggedInUserStatusBar.ResumeLayout(false);
            this.loggedInUserStatusBar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1BindingSource)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroTabControl yourAttendanceTabControl;
        private MetroFramework.Controls.MetroTabPage Attendance;
        private MetroFramework.Controls.MetroButton reportsButton;
        private MetroFramework.Controls.MetroButton clearButton;
        private MetroFramework.Controls.MetroButton saveButton;
        private MetroFramework.Controls.MetroButton addStudentButton;
        private MetroFramework.Controls.MetroButton addClassButton;
        private MetroFramework.Controls.MetroLabel selectDatePromptLabel;
        private MetroFramework.Controls.MetroLabel selectClassPromptLabel;
        private MetroFramework.Controls.MetroComboBox selectAClassComboBox;
        private System.Windows.Forms.DateTimePicker myDateTimePicker;
        private System.Windows.Forms.DataGridView reportGridView;
        private MetroFramework.Controls.MetroTabPage Reports;
        private System.Windows.Forms.StatusStrip loggedInUserStatusBar;
        private System.Windows.Forms.ToolStripStatusLabel userStatusLabel;
        private System.Windows.Forms.ToolStripStatusLabel userStatusDisplayLabel;
        private System.Windows.Forms.ToolStripStatusLabel loggedInUserDisplayLabel;
        private System.Windows.Forms.BindingSource dataSet1BindingSource;
        private DataSet1 dataSet1;
        private System.Windows.Forms.BindingSource classTBLBindingSource;
        private DataSet1TableAdapters.ClassTBLTableAdapter classTBLTableAdapter;
        private MetroFramework.Controls.MetroButton exitButton;
        private System.Windows.Forms.BindingSource recordsTBLBindingSource;
        private DataSet1TableAdapters.RecordsTBLTableAdapter RecordsTBLTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn studentNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn statusDataGridViewTextBoxColumn;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroButton getReportsOnReportsPageButton;
        private MetroFramework.Controls.MetroComboBox selectClassForReports;
        private System.Windows.Forms.ListView reportsListView;
        private System.Windows.Forms.ColumnHeader studentColumn;
        private System.Windows.Forms.ColumnHeader presentColumn;
        private System.Windows.Forms.ColumnHeader absenceColumn;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem optionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem manualToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private MetroFramework.Controls.MetroButton registerButton;
        private System.Windows.Forms.DateTimePicker ReportsDateTimePicker;
    }
}

