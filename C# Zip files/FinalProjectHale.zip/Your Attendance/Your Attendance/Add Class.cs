﻿using System;
using System.Windows.Forms;
using Your_Attendance.DataSet1TableAdapters;

namespace Your_Attendance
{

    /***************************************************************
* Name        : Add_Class
* Author      : Cody Hale
* Created     : 12/1/2019
***************************************************************/
    public partial class Add_Class : Form
    {

        // gets the UserID
        public int UserID { get; set; }

        public Add_Class()
        {
            InitializeComponent();
        }

        /**************************************************************
* Name: submitButton_Click
* Description: saves the entered class to the database
* Input: string - class anme
* Output: displays the class name in the combobox
***************************************************************/
        private void submitButton_Click(object sender, EventArgs e)
        {
            ClassTBLTableAdapter newClass = new ClassTBLTableAdapter();
            newClass.AddClassQuery(addClassTextBox.Text, UserID);

            Close();
        }

        /**************************************************************
* Name: exitButton_Click
* Description: closes the application
***************************************************************/
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}