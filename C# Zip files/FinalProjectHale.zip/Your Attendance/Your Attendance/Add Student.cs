﻿using System;
using System.Windows.Forms;

namespace Your_Attendance
{

    /***************************************************************
* Name        : Add_Student
* Author      : Cody Hale
* Created     : 12/1/2019
***************************************************************/
    public partial class Add_Student : Form
    {

        // gets the ClassID
        public int ClassID { get; set; }

        // gets the ClassName
        public string ClassName { get; set; }

        public Add_Student()
        {
            InitializeComponent();
        }


        /**************************************************************
* Name: Add_Student_Load
* Description: On load it displays the class name and class id 

***************************************************************/
        private void Add_Student_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dataSet1.StudentTBL' table. You can move, or remove it, as needed.
            this.studentTBLTableAdapter.Fill(this.dataSet1.StudentTBL);

            classNameDisplayLabel.Text = ClassName.ToString();
            classIdDisplayLabel.Text = ClassID.ToString();
        }

        /**************************************************************
* Name: exitButton_Click
* Description: closes the application
***************************************************************/
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        /**************************************************************
* Name: saveButton_Click
* Description: saves the entered data to the database
***************************************************************/
        private void saveButton_Click(object sender, EventArgs e)
        {
            this.studentTBLBindingSource.EndEdit();
            this.studentTBLTableAdapter.Update(dataSet1.StudentTBL);
        }
    }
}