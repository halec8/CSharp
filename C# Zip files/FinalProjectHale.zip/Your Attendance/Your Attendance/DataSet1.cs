﻿namespace Your_Attendance
{
    partial class DataSet1
    {
        partial class RecordsTBLDataTable
        {
        }
    }
}

namespace Your_Attendance.DataSet1TableAdapters
{
    public partial class RecordsTBLTableAdapter
    {
    }
}