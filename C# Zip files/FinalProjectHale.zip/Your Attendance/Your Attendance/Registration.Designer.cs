﻿namespace Your_Attendance
{
    partial class Registration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.registrationUserName = new MetroFramework.Controls.MetroTextBox();
            this.registrationPasswordTextBox = new MetroFramework.Controls.MetroTextBox();
            this.confirmPassTextBox = new MetroFramework.Controls.MetroTextBox();
            this.registrationUsernamePromptLabel = new MetroFramework.Controls.MetroLabel();
            this.registrationPassPromptLabel = new MetroFramework.Controls.MetroLabel();
            this.registrationConfirmPassPromptLabel = new MetroFramework.Controls.MetroLabel();
            this.registrationExitButton = new MetroFramework.Controls.MetroButton();
            this.registrationSubmitButton = new MetroFramework.Controls.MetroButton();
            this.SuspendLayout();
            // 
            // registrationUserName
            // 
            this.registrationUserName.Location = new System.Drawing.Point(168, 104);
            this.registrationUserName.Name = "registrationUserName";
            this.registrationUserName.Size = new System.Drawing.Size(400, 35);
            this.registrationUserName.TabIndex = 0;
            // 
            // registrationPasswordTextBox
            // 
            this.registrationPasswordTextBox.Location = new System.Drawing.Point(168, 245);
            this.registrationPasswordTextBox.Name = "registrationPasswordTextBox";
            this.registrationPasswordTextBox.PasswordChar = '*';
            this.registrationPasswordTextBox.Size = new System.Drawing.Size(400, 35);
            this.registrationPasswordTextBox.TabIndex = 1;
            // 
            // confirmPassTextBox
            // 
            this.confirmPassTextBox.Location = new System.Drawing.Point(168, 386);
            this.confirmPassTextBox.Name = "confirmPassTextBox";
            this.confirmPassTextBox.PasswordChar = '*';
            this.confirmPassTextBox.Size = new System.Drawing.Size(400, 35);
            this.confirmPassTextBox.TabIndex = 2;
            // 
            // registrationUsernamePromptLabel
            // 
            this.registrationUsernamePromptLabel.AutoSize = true;
            this.registrationUsernamePromptLabel.Location = new System.Drawing.Point(193, 47);
            this.registrationUsernamePromptLabel.Name = "registrationUsernamePromptLabel";
            this.registrationUsernamePromptLabel.Size = new System.Drawing.Size(71, 19);
            this.registrationUsernamePromptLabel.TabIndex = 3;
            this.registrationUsernamePromptLabel.Text = "Username:";
            // 
            // registrationPassPromptLabel
            // 
            this.registrationPassPromptLabel.AutoSize = true;
            this.registrationPassPromptLabel.Location = new System.Drawing.Point(191, 194);
            this.registrationPassPromptLabel.Name = "registrationPassPromptLabel";
            this.registrationPassPromptLabel.Size = new System.Drawing.Size(66, 19);
            this.registrationPassPromptLabel.TabIndex = 4;
            this.registrationPassPromptLabel.Text = "Password:";
            // 
            // registrationConfirmPassPromptLabel
            // 
            this.registrationConfirmPassPromptLabel.AutoSize = true;
            this.registrationConfirmPassPromptLabel.Location = new System.Drawing.Point(191, 334);
            this.registrationConfirmPassPromptLabel.Name = "registrationConfirmPassPromptLabel";
            this.registrationConfirmPassPromptLabel.Size = new System.Drawing.Size(118, 19);
            this.registrationConfirmPassPromptLabel.TabIndex = 5;
            this.registrationConfirmPassPromptLabel.Text = "Confirm Password:";
            // 
            // registrationExitButton
            // 
            this.registrationExitButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.registrationExitButton.Location = new System.Drawing.Point(129, 495);
            this.registrationExitButton.Name = "registrationExitButton";
            this.registrationExitButton.Size = new System.Drawing.Size(180, 63);
            this.registrationExitButton.TabIndex = 6;
            this.registrationExitButton.Text = "E&xit";
            this.registrationExitButton.Click += new System.EventHandler(this.registrationExitButton_Click);
            // 
            // registrationSubmitButton
            // 
            this.registrationSubmitButton.Location = new System.Drawing.Point(431, 495);
            this.registrationSubmitButton.Name = "registrationSubmitButton";
            this.registrationSubmitButton.Size = new System.Drawing.Size(180, 63);
            this.registrationSubmitButton.TabIndex = 7;
            this.registrationSubmitButton.Text = "S&ubmit";
            this.registrationSubmitButton.Click += new System.EventHandler(this.registrationSubmitButton_Click);
            // 
            // Registration
            // 
            this.AcceptButton = this.registrationSubmitButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.CancelButton = this.registrationExitButton;
            this.ClientSize = new System.Drawing.Size(776, 602);
            this.Controls.Add(this.registrationSubmitButton);
            this.Controls.Add(this.registrationExitButton);
            this.Controls.Add(this.registrationConfirmPassPromptLabel);
            this.Controls.Add(this.registrationPassPromptLabel);
            this.Controls.Add(this.registrationUsernamePromptLabel);
            this.Controls.Add(this.confirmPassTextBox);
            this.Controls.Add(this.registrationPasswordTextBox);
            this.Controls.Add(this.registrationUserName);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Registration";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Registration";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroTextBox registrationUserName;
        private MetroFramework.Controls.MetroTextBox registrationPasswordTextBox;
        private MetroFramework.Controls.MetroTextBox confirmPassTextBox;
        private MetroFramework.Controls.MetroLabel registrationUsernamePromptLabel;
        private MetroFramework.Controls.MetroLabel registrationPassPromptLabel;
        private MetroFramework.Controls.MetroLabel registrationConfirmPassPromptLabel;
        private MetroFramework.Controls.MetroButton registrationExitButton;
        private MetroFramework.Controls.MetroButton registrationSubmitButton;
    }
}