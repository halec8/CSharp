﻿namespace HelloWorldHale
{
    partial class FirstProject
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.MessageDisplay = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // MessageDisplay
            // 
            this.MessageDisplay.Location = new System.Drawing.Point(66, 28);
            this.MessageDisplay.Name = "MessageDisplay";
            this.MessageDisplay.Size = new System.Drawing.Size(467, 89);
            this.MessageDisplay.TabIndex = 0;
            this.MessageDisplay.Text = "Display Message";
            this.MessageDisplay.UseVisualStyleBackColor = true;
            this.MessageDisplay.Click += new System.EventHandler(this.Button1_Click);
            // 
            // FirstProject
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(650, 145);
            this.Controls.Add(this.MessageDisplay);
            this.Name = "FirstProject";
            this.Text = "My First Project";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button MessageDisplay;
    }
}

