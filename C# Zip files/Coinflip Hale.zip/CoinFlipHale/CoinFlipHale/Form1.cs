﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/***************************************************************
* Name        : CoinflipHale
* Author      : Cody Hale
* Created     : 08/30/2019
* Course      : CIS 169 - C#
* Version     : 1.0
* OS          : Windows 10
* Copyright   : This is my own original work based on            *               specifications issued by our instructor
* Description : This program overall description here
*               Input:  list and describe
*               Output: list and describe
* Academic Honesty: I attest that this is my original work.
* I have not used unauthorized source code, either modified or * * unmodified. I have not given other fellow student(s) access to * my program.         
***************************************************************/

namespace CoinFlipHale
{
    public partial class CoinFlip : Form
    {
        public CoinFlip()
        {
            InitializeComponent();
        }

        private void ShowHeadsButton_Click(object sender, EventArgs e)
        {
            headPicturebox.Visible = true;
            tailsPicturebox.Visible = false;
        }

        private void ShowTailsbutton_Click(object sender, EventArgs e)
        {
            tailsPicturebox.Visible = true;
            headPicturebox.Visible = false;
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
