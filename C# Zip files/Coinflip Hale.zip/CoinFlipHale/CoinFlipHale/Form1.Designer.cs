﻿namespace CoinFlipHale
{
    partial class CoinFlip
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CoinFlip));
            this.headPicturebox = new System.Windows.Forms.PictureBox();
            this.tailsPicturebox = new System.Windows.Forms.PictureBox();
            this.showHeadsbutton = new System.Windows.Forms.Button();
            this.showTailsbutton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.headPicturebox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tailsPicturebox)).BeginInit();
            this.SuspendLayout();
            // 
            // headPicturebox
            // 
            this.headPicturebox.Image = ((System.Drawing.Image)(resources.GetObject("headPicturebox.Image")));
            this.headPicturebox.Location = new System.Drawing.Point(71, 41);
            this.headPicturebox.Name = "headPicturebox";
            this.headPicturebox.Size = new System.Drawing.Size(189, 229);
            this.headPicturebox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.headPicturebox.TabIndex = 0;
            this.headPicturebox.TabStop = false;
            // 
            // tailsPicturebox
            // 
            this.tailsPicturebox.Image = ((System.Drawing.Image)(resources.GetObject("tailsPicturebox.Image")));
            this.tailsPicturebox.Location = new System.Drawing.Point(348, 41);
            this.tailsPicturebox.Name = "tailsPicturebox";
            this.tailsPicturebox.Size = new System.Drawing.Size(187, 229);
            this.tailsPicturebox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.tailsPicturebox.TabIndex = 1;
            this.tailsPicturebox.TabStop = false;
            // 
            // showHeadsbutton
            // 
            this.showHeadsbutton.Location = new System.Drawing.Point(30, 301);
            this.showHeadsbutton.Name = "showHeadsbutton";
            this.showHeadsbutton.Size = new System.Drawing.Size(160, 102);
            this.showHeadsbutton.TabIndex = 2;
            this.showHeadsbutton.Text = "Show Heads";
            this.showHeadsbutton.UseVisualStyleBackColor = true;
            this.showHeadsbutton.Click += new System.EventHandler(this.ShowHeadsButton_Click);
            // 
            // showTailsbutton
            // 
            this.showTailsbutton.Location = new System.Drawing.Point(230, 301);
            this.showTailsbutton.Name = "showTailsbutton";
            this.showTailsbutton.Size = new System.Drawing.Size(150, 102);
            this.showTailsbutton.TabIndex = 3;
            this.showTailsbutton.Text = "Show Tails";
            this.showTailsbutton.UseVisualStyleBackColor = true;
            this.showTailsbutton.Click += new System.EventHandler(this.ShowTailsbutton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(422, 294);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(164, 109);
            this.exitButton.TabIndex = 4;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // CoinFlip
            // 
            this.AcceptButton = this.showHeadsbutton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.exitButton;
            this.ClientSize = new System.Drawing.Size(598, 442);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.showTailsbutton);
            this.Controls.Add(this.showHeadsbutton);
            this.Controls.Add(this.tailsPicturebox);
            this.Controls.Add(this.headPicturebox);
            this.Name = "CoinFlip";
            this.Text = "Coin Flip";
            ((System.ComponentModel.ISupportInitialize)(this.headPicturebox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tailsPicturebox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox headPicturebox;
        private System.Windows.Forms.PictureBox tailsPicturebox;
        private System.Windows.Forms.Button showHeadsbutton;
        private System.Windows.Forms.Button showTailsbutton;
        private System.Windows.Forms.Button exitButton;
    }
}

