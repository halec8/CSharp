﻿namespace TimeZone
{
    partial class TimeZone
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.promptLabel = new System.Windows.Forms.Label();
            this.cityListBox = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.timeZoneLabel = new System.Windows.Forms.Label();
            this.okButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.clearButtom = new System.Windows.Forms.Button();
            this.submitCheckBox = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // promptLabel
            // 
            this.promptLabel.AutoSize = true;
            this.promptLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.promptLabel.Location = new System.Drawing.Point(26, 33);
            this.promptLabel.Name = "promptLabel";
            this.promptLabel.Size = new System.Drawing.Size(442, 27);
            this.promptLabel.TabIndex = 0;
            this.promptLabel.Text = "Select a city and I will give you the time zone";
            // 
            // cityListBox
            // 
            this.cityListBox.DisplayMember = "Denver";
            this.cityListBox.FormattingEnabled = true;
            this.cityListBox.ItemHeight = 25;
            this.cityListBox.Items.AddRange(new object[] {
            "Denver",
            "Honolulu",
            "Minneapolis",
            "New York",
            "San Francisco"});
            this.cityListBox.Location = new System.Drawing.Point(147, 87);
            this.cityListBox.Name = "cityListBox";
            this.cityListBox.Size = new System.Drawing.Size(174, 129);
            this.cityListBox.TabIndex = 1;
            this.cityListBox.SelectedIndexChanged += new System.EventHandler(this.CityListBox_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Location = new System.Drawing.Point(49, 252);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(122, 27);
            this.label1.TabIndex = 2;
            this.label1.Text = "Time Zone:";
            // 
            // timeZoneLabel
            // 
            this.timeZoneLabel.AutoSize = true;
            this.timeZoneLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.timeZoneLabel.Location = new System.Drawing.Point(177, 252);
            this.timeZoneLabel.Name = "timeZoneLabel";
            this.timeZoneLabel.Size = new System.Drawing.Size(2, 27);
            this.timeZoneLabel.TabIndex = 3;
            // 
            // okButton
            // 
            this.okButton.Location = new System.Drawing.Point(49, 342);
            this.okButton.Name = "okButton";
            this.okButton.Size = new System.Drawing.Size(111, 40);
            this.okButton.TabIndex = 4;
            this.okButton.Text = "&OK";
            this.okButton.UseVisualStyleBackColor = true;
            this.okButton.Click += new System.EventHandler(this.OkButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.exitButton.Location = new System.Drawing.Point(310, 342);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(117, 40);
            this.exitButton.TabIndex = 5;
            this.exitButton.Text = "E&xit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // clearButtom
            // 
            this.clearButtom.Location = new System.Drawing.Point(187, 342);
            this.clearButtom.Name = "clearButtom";
            this.clearButtom.Size = new System.Drawing.Size(100, 40);
            this.clearButtom.TabIndex = 6;
            this.clearButtom.Text = "&Clear";
            this.clearButtom.UseVisualStyleBackColor = true;
            this.clearButtom.Click += new System.EventHandler(this.ClearButtom_Click);
            // 
            // submitCheckBox
            // 
            this.submitCheckBox.AutoSize = true;
            this.submitCheckBox.Location = new System.Drawing.Point(344, 138);
            this.submitCheckBox.Name = "submitCheckBox";
            this.submitCheckBox.Size = new System.Drawing.Size(110, 29);
            this.submitCheckBox.TabIndex = 7;
            this.submitCheckBox.Text = "Submit";
            this.submitCheckBox.UseVisualStyleBackColor = true;
            this.submitCheckBox.CheckedChanged += new System.EventHandler(this.SubmitCheckBox_CheckedChanged);
            // 
            // TimeZone
            // 
            this.AcceptButton = this.okButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.exitButton;
            this.ClientSize = new System.Drawing.Size(494, 437);
            this.Controls.Add(this.submitCheckBox);
            this.Controls.Add(this.clearButtom);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.okButton);
            this.Controls.Add(this.timeZoneLabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cityListBox);
            this.Controls.Add(this.promptLabel);
            this.Name = "TimeZone";
            this.Text = "Time Zone";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label promptLabel;
        private System.Windows.Forms.ListBox cityListBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label timeZoneLabel;
        private System.Windows.Forms.Button okButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button clearButtom;
        private System.Windows.Forms.CheckBox submitCheckBox;
    }
}

