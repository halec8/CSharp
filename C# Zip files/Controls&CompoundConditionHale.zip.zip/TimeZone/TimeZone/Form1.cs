﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/***************************************************************
* Name        : TimeZoneHale
* Author      : Cody Hale
* Created     : 09/14/2019
* Course      : CIS 169 - C#
* Version     : 1.0
* OS          : Windows 10
* Copyright   : This is my own original work based on            *               specifications issued by our instructor
* Description : This program displays the timezone for the city selected.
*               Input:  city
*               Output: timezone
* Academic Honesty: I attest that this is my original work.
* I have not used unauthorized source code, either modified or * * unmodified. I have not given other fellow student(s) access to * my program.         
***************************************************************/


namespace TimeZone
{
    public partial class TimeZone : Form
    {
        public TimeZone()
        {
            InitializeComponent();
        }

        private void CityListBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void OkButton_Click(object sender, EventArgs e)
            /**************************************************************
    * Name: OkButton_Click
    * Description: once the button is clicked the program displays the timezone for the city selected.
    * Input: user selects a city
    * Output: time zone
    ***************************************************************/


        {   // creates a local variable called city
            string city;
            /* states if the city is selected and produces
            a value of zero it will perform on of the actions below 
            within the if else-if statement*/
            if (cityListBox.SelectedIndex != -1)
            {   /* has whichever city selected converted
                 to a string and stored in the local variable */
                city = cityListBox.SelectedItem.ToString();
                /* beginning of the if statement
                states if Honolulu and the submit button are checked it will
                display the string "Honolulu"*/
                if (city == "Honolulu" && submitCheckBox.Checked)
                {
                    timeZoneLabel.Text = "Hawaii-Aleutian";
                }
                /*if the city selected is San Francisco it will display
                 the string "Pacific Standard". This doesn't require both
                 the city and submit button to be selected'*/
                else if (city == "San Francisco")
                {
                    timeZoneLabel.Text = "Pacific Standard";
                }
                /*if the city selected is Denver it will display
                 the string "Mountain Standard". This doesn't require both
                 the city and submit button to be selected'*/
                else if (city == "Denver")
                {
                    timeZoneLabel.Text = "Mountain Standard";
                }

                /*if the city selected is Minneapolis it will display
                 the string "Central Standard". This doesn't require both
                 the city and submit button to be selected'*/
                else if (city == "Minneapolis")
                {
                    timeZoneLabel.Text = "Central Standard";
                }
                /*if the city selected is New York it will display
                 the string "Eastern". This doesn't require both
                 the city and submit button to be selected'*/
                else if (city == "New York")
                {
                    timeZoneLabel.Text = "Eastern";
                }
            } /* if no city is selected it will display
            a message box stating the user must select a city*/
            else
            {
                MessageBox.Show("Select a city");
            }
        }

        private void ClearButtom_Click(object sender, EventArgs e)
        {  // This clears the data in the timeZoneLabel
            timeZoneLabel.Text = String.Empty;
        }

        private void ExitButton_Click(object sender, EventArgs e)
        { // the Exit Button allows the user to exit the program
            this.Close();
        }

        private void SubmitCheckBox_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}

