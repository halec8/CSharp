﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

/***************************************************************
* Name        : AverageTestScoresWhileHale
* Author      : Cody Hale
* Created     : 9/18/2019
* Course      : CIS 169 - C#
* Version     : 1.0
* OS          : Windows10
* Copyright   : This is my own original work based on            *               specifications issued by our instructor
* Description : Gathers input from the user for 3 test scores, calculates the average, then displays
*               Input:  the user inputs the test score values
*               Output: test score average
* Academic Honesty: I attest that this is my original work.
* I have not used unauthorized source code, either modified or * * unmodified. I have not given other fellow student(s) access to * my program.         
***************************************************************/


namespace AverageTestScoresHale
{ 
    /***************************************************************
* Name        : AverageTestScoreWhile
* Author      : Cody Hale
* Created     : 9/18/2019
***************************************************************/

    class AverageTestScoreWhile
    {
        static void Main(string[] args)
        { 
            // declare local variables
            double testAverage;
            int Count = 0;

            // get user input and stores as a variable

            Console.Write("Enter first test score: ");

            string test1 = Console.ReadLine();
            double test1Score = Double.Parse(test1);

            Console.Write("Enter second test score: ");

            string test2 = Console.ReadLine();
            double test2Score = Double.Parse(test2);

            Console.Write("Enter the third test score: ");

            string test3 = Console.ReadLine();
            double test3Score = double.Parse(test3);

            /**************************************************************
* Name: While
* Description: while the boolean is true it continually executes the program and displays the average
* Input: test1, test2, test3
* Output: test average
***************************************************************/

            while (Count < 1)
            {
                testAverage = (test3Score + test2Score + test3Score) / 3;

                Console.WriteLine("Your test average is: " + testAverage.ToString());

                Console.Read();

                Count = Count += 1;

                Console.WriteLine("To exit press esc or enter");
            }
        }
    }
}
